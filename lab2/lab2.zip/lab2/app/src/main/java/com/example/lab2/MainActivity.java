package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Gson gson = new Gson();
    List<Student> students;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            FileInputStream fin = openFileInput("students.json");
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);
            String json = new String (bytes);
            students = gson.fromJson(json, TypeToken.getParameterized(List.class, Student.class).getType());
            fin.close();

            if (students  != null) {
                for (Student student : students) {
                    System.out.println(student.firstName);
                }
            }
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        Button btn = findViewById(R.id.createStudent);
        btn.setOnClickListener(v -> {
            Intent intent = new Intent(this, FirstStep.class);
            startActivity(intent);
        });
    }
}