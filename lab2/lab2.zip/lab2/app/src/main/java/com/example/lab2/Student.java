package com.example.lab2;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Student
{
    String firstName;
    String lastName;
    String middleName;
    String faculty;
    String speciality;
    String admissionDate;
    Activity context;
    int course;
    private final static String FILE_NAME = "students.json";

    public Student
    (
        String firstName,
        String lastName,
        String middleName,
        String faculty,
        String speciality,
        String admissionDate,
        int course,
        Activity context
    ) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.middleName = middleName;
        this.faculty = faculty;
        this.speciality = speciality;
        this.admissionDate = admissionDate;
        this.course = course;
        this.context = context;
    }

    public void addNewStudent() {
        Gson gson = new Gson();
        List<Student> students;

        try {
            FileInputStream fin = context.openFileInput(FILE_NAME);
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);
            String input = new String(bytes);
            students = gson.fromJson(input, new TypeToken<List<Student>>() {}.getType());
            fin.close();

            if (students == null) {
                students = new ArrayList<>();
            }

            students.add(Student.this);

            FileOutputStream fos = context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            String output = gson.toJson(students, new TypeToken<List<Student>>() {}.getType());
//            fos.write(output.getBytes());
//            fos.close();
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
